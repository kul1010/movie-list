import React,{Component} from 'react'

export default (props)=>{
    return (
        <h3>About Us</h3>
    )
}