import React,{Component} from 'react'
import MovieList from '../components/MovieList'

export default (props)=>{
    return (
        <MovieList />
    )
}