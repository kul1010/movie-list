1. npm i 
2. npm start
3. click on navigation Movies
4. I have also added Pagination